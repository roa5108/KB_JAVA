package ch06;

public class CarExample3 {
    public static void main(String[] args) {
        Car4 myCar = new Car4("포르쉐");
        Car4 yourCar = new Car4("벤츠");
        myCar.run();
        yourCar.run();
    }
}
