package ch06;

public class Korean {
    //필드 선언
    String nation = "대한민국";
    String name;
    String ssn;


    //Alt+Insert 키로 생성자 코드
    public Korean() {
    }

    public Korean(String name, String ssn) {
        this.name = name;
        this.ssn = ssn;
    }
}
